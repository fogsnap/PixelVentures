package com.integration;

import org.junit.Assert;
import org.junit.Test;

public class TestServices {

	private String INPUT = "13412";
	@Test
	public void endToendComp1() {
		Assert.assertEquals(INPUT,"13412");
	}

	@Test
	public void endToendComp2() {
		Assert.assertEquals(INPUT,"13412");
	}

	@Test
	public void endToendComp3() {
		Assert.assertEquals(INPUT,"13412");
	}


}
