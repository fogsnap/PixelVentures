package com.integration;

import org.junit.Assert;
import org.junit.Test;

public class TestComponents {

	private String INPUT = "13412";
	@Test
	public void endToendService1() {
		Assert.assertEquals(INPUT,"13412");
	}

	@Test
	public void endToendService2() {
		Assert.assertEquals(INPUT,"13412");
	}

	@Test
	public void endToendService3() {
		Assert.assertEquals(INPUT,"13412");
	}

	@Test
	public void endToendService4() {
		Assert.assertEquals(INPUT,"13412");
	}
}
