package com.sa.web;

import org.junit.Assert;
import org.junit.Test;

public class ControllerTest {

	private String INPUT = "13413";
	@Test
	public void testAPI1() {
		Assert.assertEquals(INPUT,"13413");
	}


	@Test
	public void testAPI2() {
		Assert.assertEquals(INPUT,"13413");
	}
}
